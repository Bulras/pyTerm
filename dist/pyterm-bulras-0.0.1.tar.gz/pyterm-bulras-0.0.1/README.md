# pyTerm
Python module that you can import in your project to run a terminal